// MirUI.hpp — единая точка входа (обновлённая).
// Теперь включает ВСЁ, включая Designer/Canvas/Handles,
// Designer/Inspector (BooleanEditor, NumberEditor, StringEditor),
// Designer/Canvas/CanvasModel, SnapManager, HitTest,
// Renderers/PlatformAdapter, Renderers/SwiftUI (заглушки),
// Widgets/Container.
//
// Чистый C++23, без платформенных зависимостей.

#pragma once

// ================================================================
// Foundation
// ================================================================
#include "Foundation/Color/Color.hpp"
#include "Foundation/Color/ColorPalette.hpp"
#include "Foundation/Metrics/Metrics.hpp"
#include "Foundation/Animation/Animation.hpp"
#include "Foundation/Animation/AnimationSpec.hpp"
#include "Foundation/Typography/Font.hpp"
#include "Foundation/Typography/Typography.hpp"
#include "Foundation/Icons/IconID.hpp"

// ================================================================
// Core
// ================================================================
#include "Core/Widget/WidgetID.hpp"
#include "Core/Widget/WidgetType.hpp"
#include "Core/Widget/Widget.hpp"
#include "Core/Widget/WidgetTree.hpp"
#include "Core/Widget/PropertyType.hpp"
#include "Core/Widget/PropertyDescriptor.hpp"
#include "Core/Widget/WidgetFactory.hpp"

#include "Core/Layout/Point.hpp"
#include "Core/Layout/Size.hpp"
#include "Core/Layout/Rect.hpp"
#include "Core/Layout/Insets.hpp"
#include "Core/Layout/LayoutConstraints.hpp"
#include "Core/Layout/LayoutNode.hpp"
#include "Core/Layout/LayoutEngine.hpp"
#include "Core/Layout/Unit.hpp"
#include "Core/Layout/LayoutData.hpp"
#include "Core/Layout/Transform.hpp"

#include "Core/Theme/Theme.hpp"
#include "Core/Theme/ThemeManager.hpp"

#include "Core/State/StateValue.hpp"
#include "Core/State/StateKey.hpp"
#include "Core/State/StateStore.hpp"
#include "Core/State/PropertyValue.hpp"

#include "Core/Commands/CommandID.hpp"
#include "Core/Commands/Command.hpp"
#include "Core/Commands/CommandContext.hpp"
#include "Core/Commands/CommandBus.hpp"
#include "Core/Commands/CommandHistory.hpp"

#include "Core/Events/EventType.hpp"
#include "Core/Events/Event.hpp"
#include "Core/Events/EventDispatcher.hpp"

#include "Core/Focus/FocusManager.hpp"

#include "Core/Rendering/Renderer.hpp"
#include "Core/Rendering/RenderCommand.hpp"
#include "Core/Rendering/RenderCommandBuffer.hpp"
#include "Core/Rendering/WidgetRenderer.hpp"

#include "Core/Selection/SelectionManager.hpp"

// ================================================================
// Widgets
// ================================================================
#include "Widgets/Button/Button.hpp"
#include "Widgets/Label/Label.hpp"
#include "Widgets/Toolbar/Toolbar.hpp"
#include "Widgets/Tree/TreeNode.hpp"
#include "Widgets/Tree/Tree.hpp"
#include "Widgets/PropertyGrid/Property.hpp"
#include "Widgets/PropertyGrid/PropertyGrid.hpp"
#include "Widgets/Viewport/Viewport.hpp"
#include "Widgets/Container/Container.hpp"

// ================================================================
// Workspace
// ================================================================
#include "Workspace/PanelManager/PanelDescriptor.hpp"
#include "Workspace/PanelManager/PanelManager.hpp"
#include "Workspace/WorkspaceManager/Workspace.hpp"
#include "Workspace/WorkspaceManager/WorkspaceManager.hpp"
#include "Workspace/LayoutManager/LayoutManager.hpp"
#include "Workspace/WindowManager/WindowDescriptor.hpp"
#include "Workspace/WindowManager/WindowManager.hpp"

// ================================================================
// Designer
// ================================================================
// Document
#include "Designer/Document/UIDocument.hpp"
#include "Designer/Document/UIFormatVersion.hpp"
#include "Designer/Document/UIReader.hpp"
#include "Designer/Document/UIWriter.hpp"

// Commands
#include "Designer/Commands/AddWidgetCommand.hpp"
#include "Designer/Commands/DeleteWidgetCommand.hpp"
#include "Designer/Commands/MoveWidgetCommand.hpp"
#include "Designer/Commands/ResizeWidgetCommand.hpp"
#include "Designer/Commands/ChangePropertyCommand.hpp"
#include "Designer/Commands/RenameWidgetCommand.hpp"

// Canvas & Handles
#include "Designer/Canvas/DesignerCanvas.hpp"
#include "Designer/Canvas/DragController.hpp"
#include "Designer/Canvas/GridManager.hpp"
#include "Designer/Canvas/GuideManager.hpp"
#include "Designer/Canvas/ResizeController.hpp"
#include "Designer/Canvas/CanvasModel.hpp"
#include "Designer/Canvas/SnapManager.hpp"
#include "Designer/Canvas/HitTest.hpp"
#include "Designer/Canvas/Handles/SelectionFrame.hpp"
#include "Designer/Canvas/Handles/ResizeHandle.hpp"
#include "Designer/Canvas/Handles/RotationHandle.hpp"

// History
#include "Designer/History/DesignerHistory.hpp"

// Inspector
#include "Designer/Inspector/InspectorModel.hpp"
#include "Designer/Inspector/PropertyEditor.hpp"
#include "Designer/Inspector/PropertyEditorFactory.hpp"
#include "Designer/Inspector/ColorEditor.hpp"
#include "Designer/Inspector/EnumEditor.hpp"
#include "Designer/Inspector/FontEditor.hpp"
#include "Designer/Inspector/SizeEditor.hpp"
#include "Designer/Inspector/BooleanEditor.hpp"
#include "Designer/Inspector/NumberEditor.hpp"
#include "Designer/Inspector/StringEditor.hpp"

// Preview
#include "Designer/Preview/PreviewManager.hpp"
#include "Designer/Preview/PreviewMode.hpp"

// Themes
#include "Designer/Themes/ColorTokenEditor.hpp"
#include "Designer/Themes/MetricsEditor.hpp"
#include "Designer/Themes/TypographyEditor.hpp"
#include "Designer/Themes/ThemeEditor.hpp"

// Toolbox
#include "Designer/Toolbox/ToolboxItem.hpp"
#include "Designer/Toolbox/ToolboxModel.hpp"
#include "Designer/Toolbox/Toolbox.hpp"

// Application
#include "Designer/Application/DesignerState.hpp"
#include "Designer/Application/DesignerApplication.hpp"

// ================================================================
// Schema
// ================================================================
#include "Schema/CommandSchema.hpp"
#include "Schema/EventSchema.hpp"
#include "Schema/LayoutSchema.hpp"
#include "Schema/PropertySchema.hpp"
#include "Schema/ThemeSchema.hpp"
#include "Schema/WidgetSchema.hpp"

// ================================================================
// Renderers (базовые адаптеры, платформенные — только заглушки)
// ================================================================
#include "Renderers/NullRenderer.hpp"
#include "Renderers/PlatformAdapter.hpp"
// SwiftUI-адаптер (заглушка, будет дописан после настройки моста)
// #include "Renderers/SwiftUI/SwiftUIRenderer.hpp"