// MirUI/Core/Runtime/UIRuntime.hpp
// 🧠 Главный управляющий объект MirUI — единый вход для всего приложения.
//
// UIRuntime владеет всеми ключевыми компонентами ядра и предоставляет
// к ним удобный доступ. Он НЕ зависит от платформы и используется
// как редактором (Designer), так и рендерерами (SwiftUI, WinUI).
//
// В отличие от UIContext, который является просто контейнером данных,
// UIRuntime дополнительно управляет жизненным циклом: инициализацией,
// завершением работы, главным циклом обновления и рендерингом.
//
// Именно UIRuntime будет создаваться при старте приложения и
// передаваться в платформенные адаптеры.
//
// Чистый C++23, без платформенных зависимостей.

#pragma once

#include "../UIContext.hpp"
#include "../Rendering/Renderer.hpp"
#include "../../Foundation/Animation/AnimationSpec.hpp"
#include <memory>
#include <chrono>

namespace MirUI {

class UIRuntime {
public:
    // ── Конструктор ──────────────────────────────────────────
    UIRuntime()
        : m_context(std::make_unique<UIContext>())
        , m_renderer(nullptr)
        , m_running(false)
        , m_lastFrameTime(std::chrono::steady_clock::now())
    {
    }

    // ── Доступ к контексту ───────────────────────────────────
    [[nodiscard]] UIContext& context() { return *m_context; }
    [[nodiscard]] const UIContext& context() const { return *m_context; }

    // ── Подключение рендерера ────────────────────────────────
    // Рендерер (SwiftUI, WinUI, NullRenderer) подключается к рантайму,
    // чтобы получать обновления и отправлять события.
    void setRenderer(Renderer* renderer) {
        m_renderer = renderer;
    }
    [[nodiscard]] Renderer* renderer() const { return m_renderer; }

    // ── Жизненный цикл ───────────────────────────────────────
    // Инициализация: создаёт корневое окно и регистрирует темы.
    void initialize() {
        // Регистрируем встроенные темы
        m_context->themeManager().registerTheme(Theme::createLight());
        m_context->themeManager().registerTheme(Theme::createDark());
        m_running = true;
    }

    // Завершение работы: освобождает ресурсы.
    void shutdown() {
        m_running = false;
        m_renderer = nullptr;
    }

    // ── Главный цикл обновления ──────────────────────────────
    // Вызывается каждый кадр (обычно 60 раз в секунду).
    // Обновляет анимации, выполняет компоновку и запускает рендеринг.
    void update() {
        if (!m_running) return;

        // Вычисляем время, прошедшее с прошлого кадра.
        auto now = std::chrono::steady_clock::now();
        double deltaTime = std::chrono::duration<double>(now - m_lastFrameTime).count();
        m_lastFrameTime = now;

        // Ограничиваем максимальное deltaTime, чтобы избежать скачков.
        if (deltaTime > 0.1) deltaTime = 0.016; // 60 FPS fallback

        // Обновляем анимации.
        m_context->animationManager().update(deltaTime);

        // Выполняем компоновку.
        m_context->layout();

        // Запускаем рендерер, если он подключён.
        if (m_renderer) {
            m_renderer->beginFrame();
            m_renderer->render(m_context->widgetTree());
            m_renderer->endFrame();
        }
    }

    // ── Удобные делегаты к контексту ─────────────────────────
    void switchTheme(const ThemeID& id) { m_context->switchTheme(id); }
    void undo() { m_context->undo(); }
    void redo() { m_context->redo(); }

    WidgetID addWidget(WidgetType type, WidgetID parentId) {
        return m_context->addWidget(type, parentId);
    }

    Widget* findWidget(const WidgetID& id) {
        return m_context->widgetTree().find(id);
    }

private:
    std::unique_ptr<UIContext> m_context;
    Renderer* m_renderer = nullptr;
    bool m_running = false;
    std::chrono::steady_clock::time_point m_lastFrameTime;
};

} // namespace MirUI