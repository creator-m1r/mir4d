// MirUI/Core/Widget/WidgetFactory.hpp — финальная версия с CheckBox, TextField, ComboBox, Slider.
//
// Чистый C++23, без платформенных зависимостей.

#pragma once

#include "Widget.hpp"
#include "WidgetType.hpp"
#include <memory>

// Подключаем конкретные виджеты.
#include "../../Widgets/Button/Button.hpp"
#include "../../Widgets/Label/Label.hpp"
#include "../../Widgets/Toolbar/Toolbar.hpp"
#include "../../Widgets/Tree/Tree.hpp"
#include "../../Widgets/PropertyGrid/PropertyGrid.hpp"
#include "../../Widgets/Viewport/Viewport.hpp"
#include "../../Widgets/Container/Container.hpp"

// Новые виджеты форм и ввода.
#include "../../Widgets/CheckBox/CheckBox.hpp"
#include "../../Widgets/TextField/TextField.hpp"
#include "../../Widgets/ComboBox/ComboBox.hpp"
#include "../../Widgets/Slider/Slider.hpp"

namespace MirUI {

class WidgetFactory {
public:
    // ── Главный метод создания ──────────────────────────────
    static std::unique_ptr<Widget> create(WidgetType type) {
        switch (type) {
            // Базовые виджеты
            case WidgetType::Button:
                return std::make_unique<Button>();
            case WidgetType::Label:
                return std::make_unique<Label>();
            case WidgetType::Toolbar:
                return std::make_unique<Toolbar>();
            case WidgetType::Tree:
                return std::make_unique<Tree>();
            case WidgetType::PropertyGrid:
                return std::make_unique<PropertyGrid>();
            case WidgetType::Viewport:
                return std::make_unique<Viewport>();

            // Новые виджеты форм
            case WidgetType::CheckBox:
                return std::make_unique<CheckBox>();
            case WidgetType::TextField:
                return std::make_unique<TextField>();
            case WidgetType::ComboBox:
                return std::make_unique<ComboBox>();
            case WidgetType::Slider:
                return std::make_unique<Slider>();

            // Контейнеры
            case WidgetType::Window:
            case WidgetType::Panel:
            case WidgetType::DockPanel:
            case WidgetType::Ribbon:
            case WidgetType::Timeline:
                return std::make_unique<Widget>(type);

            default:
                return nullptr;
        }
    }
};

} // namespace MirUI