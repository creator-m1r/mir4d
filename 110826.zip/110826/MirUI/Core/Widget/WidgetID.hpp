// MirUI/Core/Widget/WidgetID.hpp
// 🏷️ Уникальный строковый идентификатор любого элемента интерфейса.
//
// Вместо чисел или случайных хешей MirUI использует осмысленные строки,
// например "mainWindow", "createButton", "projectTree".
// Это делает код читаемым и позволяет легко находить элементы в отладчике.
//
// Чистый C++23, без платформенных зависимостей.

#pragma once

#include <string>
#include <atomic>
#include <functional>

namespace MirUI {

class WidgetID {
public:
    // Создаёт пустой (невалидный) идентификатор.
    WidgetID() noexcept = default;

    // Создание из осмысленного имени.
    explicit WidgetID(std::string name) noexcept : m_name(std::move(name)) {}
    explicit WidgetID(const char* name) noexcept : m_name(name) {}

    // Генерация нового уникального ID (потокобезопасно).
    static WidgetID generate() noexcept {
        static std::atomic<uint64_t> counter{1};
        return WidgetID("widget_" + std::to_string(counter.fetch_add(1, std::memory_order_relaxed)));
    }

    // Доступ к хранимой строке.
    [[nodiscard]] const std::string& str() const noexcept { return m_name; }
    [[nodiscard]] const char* c_str() const noexcept { return m_name.c_str(); }

    // Приведение к строке для совместимости.
    [[nodiscard]] operator const std::string&() const noexcept { return m_name; }

    // Операторы сравнения.
    friend bool operator==(const WidgetID& lhs, const WidgetID& rhs) noexcept {
        return lhs.m_name == rhs.m_name;
    }
    friend bool operator!=(const WidgetID& lhs, const WidgetID& rhs) noexcept {
        return lhs.m_name != rhs.m_name;
    }
    friend bool operator<(const WidgetID& lhs, const WidgetID& rhs) noexcept {
        return lhs.m_name < rhs.m_name;
    }

private:
    std::string m_name;
};

} // namespace MirUI

// Специализация std::hash для использования WidgetID в unordered-контейнерах.
namespace std {
template <>
struct hash<MirUI::WidgetID> {
    std::size_t operator()(const MirUI::WidgetID& id) const noexcept {
        return hash<std::string>{}(id.str());
    }
};
} // namespace std