// MirUI/Core/Widget/WidgetType.hpp
// 📦 Расширенный список всех типов виджетов MirUI.
// Добавлены CheckBox, TextField, ComboBox, Slider, RadioButton, ProgressBar,
// Image, TableView, ScrollView, TabView.
//
// Чистый C++23, без платформенных зависимостей.

#pragma once

namespace MirUI {

enum class WidgetType {
    Unknown,
    Window,
    Panel,
    Button,
    Label,
    Tree,
    PropertyGrid,
    Ribbon,
    Toolbar,
    DockPanel,
    Viewport,
    Timeline,

    // Формы и элементы ввода
    CheckBox,     // флажок (галочка)
    TextField,    // текстовое поле ввода
    ComboBox,     // выпадающий список
    Slider,       // ползунок для выбора числа
    RadioButton,  // радиокнопка (выбор одного из группы)
    ProgressBar,  // индикатор прогресса

    // Дополнительные виджеты
    Image,        // изображение
    TableView,    // таблица
    ScrollView,   // прокручиваемая область
    TabView       // панель с вкладками
};

} // namespace MirUI