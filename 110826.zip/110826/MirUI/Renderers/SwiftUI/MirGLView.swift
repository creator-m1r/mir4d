import SwiftUI
import AppKit

final class MirGLCustomView: NSView {

    private var context: UnsafeMutableRawPointer?
    private var renderer: UnsafeMutableRawPointer?

    private var timer: Timer?

    override var wantsUpdateLayer: Bool {
        true
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()

        if window != nil {
            setupEngine()
            startRendering()
        } else {
            stopRendering()
            shutdownEngine()
        }
    }

    override func layout() {
        super.layout()

        resizeEngine()
    }

    private func setupEngine() {

        guard context == nil else {
            return
        }

        let width = max(
            Int(bounds.width),
            1
        )

        let height = max(
            Int(bounds.height),
            1
        )

        let viewPointer =
            Unmanaged.passUnretained(self)
                .toOpaque()

        context =
            MirEngineCreateMacOpenGLContext(
                viewPointer,
                MirEngineSize2D(
                    width: UInt32(width),
                    height: UInt32(height)
                )
            )

        guard let context else {
            print("MirEngine: context creation failed")
            return
        }

        renderer =
            MirEngineCreateOpenGLRenderer(
                context
            )

        guard let renderer else {
            print("MirEngine: renderer creation failed")
            return
        }

        guard MirEngineInitializeRenderer(
            renderer
        ) else {
            print("MirEngine: renderer initialization failed")
            return
        }
    }

    private func startRendering() {

        guard timer == nil else {
            return
        }

        timer = Timer.scheduledTimer(
            withTimeInterval: 1.0 / 60.0,
            repeats: true
        ) { [weak self] _ in

            self?.renderFrame()
        }
    }

    private func stopRendering() {

        timer?.invalidate()

        timer = nil
    }

    private func renderFrame() {

        guard let renderer else {
            return
        }

        MirEngineRender(
            renderer
        )
    }

    private func resizeEngine() {

        guard let renderer else {
            return
        }

        let width = max(
            Int(bounds.width),
            1
        )

        let height = max(
            Int(bounds.height),
            1
        )

        MirEngineResize(
            renderer,
            UInt32(width),
            UInt32(height)
        )
    }

    private func shutdownEngine() {

        stopRendering()

        if let renderer {
            MirEngineDestroyRenderer(
                renderer
            )

            self.renderer = nil
        }

        if let context {
            MirEngineDestroyOpenGLContext(
                context
            )

            self.context = nil
        }
    }

    deinit {
        shutdownEngine()
    }
}

struct MirGLView: NSViewRepresentable {

    func makeNSView(
        context: Context
    ) -> MirGLCustomView {

        MirGLCustomView()
    }

    func updateNSView(
        _ nsView: MirGLCustomView,
        context: Context
    ) {
    }
}