import SwiftUI

@main
struct MirEngineApp: App {

    var body: some Scene {

        WindowGroup {

            MirGLView()
                .frame(
                    minWidth: 1000,
                    minHeight: 700
                )
        }
    }
}