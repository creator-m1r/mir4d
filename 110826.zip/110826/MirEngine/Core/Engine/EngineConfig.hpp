// MirEngine/Core/Engine/EngineConfig.hpp
// ⚙️ Настройки движка MirEngine — конфигурация, передаваемая при создании.
//
// EngineConfig позволяет настроить поведение движка без изменения кода.
// Его передают в конструктор Engine (будет доработан позже) или в метод
// initialize(). Это как пульт управления с переключателями: хочешь —
// включи логирование, хочешь — отключи проверки ошибок.
//
// Все поля имеют разумные значения по умолчанию, поэтому если передать
// EngineConfig{}, движок будет работать "из коробки".
//
// Поля:
//   • enableLogging     — писать ли сообщения в лог (true = писать).
//   • enableValidation  — выполнять ли дополнительные проверки (assert).
//                          В релизных сборках обычно отключают для скорости.
//   • logLevel          — минимальный уровень сообщений для записи в лог.
//   • applicationName   — имя приложения (для заголовков логов и т.д.).
//
// Использование:
//   EngineConfig config;
//   config.enableLogging = true;
//   config.applicationName = "MIR4D";
//   Engine engine(config);
//
// Чистый C++23, без внешних зависимостей.

#pragma once

#include <string>

namespace mir {

struct EngineConfig {
    // Включить запись логов?
    // true — все сообщения уровня logLevel и выше будут записываться.
    // false — логирование отключено полностью.
    bool enableLogging = true;

    // Включить дополнительные проверки (assert)?
    // true — в отладочных сборках будут срабатывать assert'ы при ошибках.
    // false — проверки отключены (для релизной сборки).
    bool enableValidation = true;

    // Минимальный уровень логирования.
    // Сообщения с уровнем ниже этого НЕ будут записываться.
    // Уровни (по возрастанию): Trace, Debug, Info, Warning, Error, Critical.
    // Значение по умолчанию "Info" означает, что Trace и Debug не пишутся.
    int logLevel = 2;   // 0=Trace, 1=Debug, 2=Info, 3=Warning, 4=Error, 5=Critical

    // Имя приложения.
    // Используется в заголовках логов, именах файлов, метаданных.
    std::string applicationName = "MirEngine";
};

} // namespace mir