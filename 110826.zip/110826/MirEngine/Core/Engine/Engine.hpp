// MirEngine/Core/Engine/Engine.hpp
// ⚙️ Главный класс движка MirEngine — владеет всеми ключевыми подсистемами.
//
// Engine — это центральная точка входа в MirEngine. Он создаётся один раз
// при старте приложения и предоставляет доступ к:
//   • IDGenerator    — генератору уникальных идентификаторов
//   • Logger         — системе логирования
//   • (в будущем)    — менеджерам сцен, документов, геометрии, рендеринга
//
// Engine управляет жизненным циклом движка: его можно инициализировать,
// проверить состояние и корректно завершить работу. Никаких глобальных
// переменных — всё хранится внутри Engine и передаётся по ссылке тем,
// кому нужно.
//
// Использование:
//   Engine engine;
//   engine.initialize();
//   auto& gen = engine.idGenerator();
//   EntityID id = gen.createEntity();
//   engine.logger().info("Движок запущен");
//   engine.shutdown();
//
// Чистый C++23, без внешних зависимостей.

#pragma once

#include "../Result/Result.hpp"         // Result<void>, ErrorCode
#include "../IDs/IDGenerator.hpp"       // IDGenerator
#include "../Logging/Logger.hpp"        // Logger
#include <memory>                       // std::unique_ptr

namespace mir {

class Engine {
public:
    // ── Конструктор ──────────────────────────────────────────
    // Создаёт движок в неинициализированном состоянии.
    Engine();

    // ── Деструктор ───────────────────────────────────────────
    // Автоматически вызывает shutdown(), если движок был инициализирован.
    ~Engine();

    // ── Запрет копирования и перемещения ─────────────────────
    // Engine — это единственный владелец всех ресурсов.
    // Копирование или перемещение нарушило бы инварианты.
    Engine(const Engine&) = delete;
    Engine& operator=(const Engine&) = delete;
    Engine(Engine&&) = delete;
    Engine& operator=(Engine&&) = delete;

    // ── Инициализация ────────────────────────────────────────
    // Выделяет ресурсы и готовит движок к работе.
    // Должен быть вызван до использования любых подсистем.
    Result<void> initialize();

    // ── Завершение работы ───────────────────────────────────
    // Корректно освобождает все ресурсы.
    void shutdown();

    // ── Проверка состояния ──────────────────────────────────
    // Возвращает true, если движок был успешно инициализирован
    // и готов к использованию.
    [[nodiscard]] bool isInitialized() const noexcept;

    // ── Генератор идентификаторов ───────────────────────────
    // Через этот объект создаются все уникальные ID в системе:
    // EntityID, ObjectID, ComponentID, FeatureID, DocumentID, ProjectID.
    [[nodiscard]] IDGenerator& idGenerator() noexcept;
    [[nodiscard]] const IDGenerator& idGenerator() const noexcept;

    // ── Логгер ──────────────────────────────────────────────
    // Центральная система логирования движка.
    [[nodiscard]] Logger& logger() noexcept;
    [[nodiscard]] const Logger& logger() const noexcept;

private:
    std::unique_ptr<IDGenerator> m_idGenerator;   // владеет генератором ID
    std::unique_ptr<Logger>      m_logger;         // владеет логгером
    bool m_initialized = false;                    // флаг состояния
};

} // namespace mir