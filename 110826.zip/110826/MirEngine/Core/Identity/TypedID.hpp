#pragma once

#include <cstdint>
#include <functional>

namespace mir
{

template<typename Tag>
class TypedID
{
public:

    using ValueType = std::uint64_t;

    constexpr TypedID() noexcept = default;

    explicit constexpr TypedID(ValueType value) noexcept
        : m_value(value)
    {
    }

    constexpr ValueType value() const noexcept
    {
        return m_value;
    }

    constexpr bool valid() const noexcept
    {
        return m_value != 0;
    }

    constexpr explicit operator bool() const noexcept
    {
        return valid();
    }

    friend constexpr bool operator==(
        TypedID lhs,
        TypedID rhs) noexcept
    {
        return lhs.m_value == rhs.m_value;
    }

    friend constexpr bool operator!=(
        TypedID lhs,
        TypedID rhs) noexcept
    {
        return lhs.m_value != rhs.m_value;
    }

private:

    ValueType m_value = 0;
};

struct VertexIDTag {};
struct EdgeIDTag {};
struct LoopIDTag {};
struct FaceIDTag {};
struct ShellIDTag {};
struct SolidIDTag {};
struct BodyIDTag {};

using VertexID = TypedID<VertexIDTag>;
using EdgeID   = TypedID<EdgeIDTag>;
using LoopID   = TypedID<LoopIDTag>;
using FaceID   = TypedID<FaceIDTag>;
using ShellID  = TypedID<ShellIDTag>;
using SolidID  = TypedID<SolidIDTag>;
using BodyID   = TypedID<BodyIDTag>;

}