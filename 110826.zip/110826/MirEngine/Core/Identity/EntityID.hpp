#pragma once

#include <cstdint>
#include <functional>

namespace mir
{

using EntityID = std::uint64_t;

constexpr EntityID InvalidEntityID = 0;

struct EntityIDGenerator
{
    static EntityID next()
    {
        static EntityID value = 1;
        return value++;
    }
};

template<typename T>
struct EntityIDHash
{
    std::size_t operator()(const T& value) const noexcept
    {
        return std::hash<EntityID>{}(value.id);
    }
};

}