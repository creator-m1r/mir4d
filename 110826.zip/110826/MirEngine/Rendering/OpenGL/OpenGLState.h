#pragma once

#include <cstdint>

namespace MirEngine::Rendering {

class OpenGLState {
public:

    void initialize();

    void setViewport(
        uint32_t width,
        uint32_t height
    );

    void beginFrame();

    void endFrame();
};

}