#include "OpenGLRenderer.h"

#include "OpenGLContext.h"
#include "OpenGLDevice.h"

#include <OpenGL/gl3.h>

namespace MirEngine::Rendering {

OpenGLRenderer::OpenGLRenderer(
    OpenGLContext* context)
    : m_context(context)
{
}

OpenGLRenderer::~OpenGLRenderer() = default;

bool OpenGLRenderer::initialize()
{
    if (!m_context) {
        return false;
    }

    m_context->makeCurrent();

    m_device =
        std::make_unique<OpenGLDevice>(
            m_context
        );

    if (!m_device->initialize()) {
        m_device.reset();

        return false;
    }

    glClearColor(
        0.055f,
        0.065f,
        0.085f,
        1.0f
    );

    m_initialized = true;

    return true;
}

void OpenGLRenderer::render()
{
    if (!m_initialized) {
        return;
    }

    m_device->beginFrame();

    /*
        Первый тестовый кадр.

        Пока здесь ничего нет.
        Следующим этапом сюда пойдут:

            GridPass
            GeometryPass
            SelectionPass
            GizmoPass
            OverlayPass
    */

    m_device->endFrame();
}

void OpenGLRenderer::resize(
    uint32_t width,
    uint32_t height)
{
    if (!m_initialized) {
        return;
    }

    m_device->resize(
        width,
        height
    );
}

}