#pragma once

#include <cstdint>

namespace MirEngine::Rendering {

struct Size2D {
    uint32_t width  = 1;
    uint32_t height = 1;
};

using NativeWindowHandle = void*;

class OpenGLContext {
public:

    virtual ~OpenGLContext() = default;

    virtual bool initialize(
        NativeWindowHandle window,
        const Size2D& size
    ) = 0;

    virtual void makeCurrent() = 0;

    virtual void swapBuffers() = 0;

    virtual void resize(const Size2D& size) = 0;

    virtual Size2D size() const = 0;
};

}