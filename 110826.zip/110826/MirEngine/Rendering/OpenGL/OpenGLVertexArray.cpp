// MirEngine/Rendering/OpenGL/OpenGLVertexArray.cpp
// =================================================================================
// Реализация вершинного массива OpenGL (VAO).
//
// Связывает вершинный и индексный буферы, настраивает расположение атрибутов
// с использованием современного подхода OpenGL 4.1:
//   - glVertexAttribFormat (формат атрибута)
//   - glVertexAttribBinding (привязка атрибута к binding point)
//   - glBindVertexBuffer (привязка буфера к binding point)
//   - glEnableVertexAttribArray
//
// Это заменяет устаревший glVertexAttribPointer и даёт более гибкий контроль.
//
// Зависимости:
//   - glbinding (OpenGL-функции)
//   - spdlog (логирование)
// =================================================================================

#include "OpenGLVertexArray.h"
#include "OpenGLVertexBuffer.h"   // для dynamic_cast
#include "OpenGLIndexBuffer.h"    // для dynamic_cast

#include <spdlog/spdlog.h>
#include <glbinding/gl/gl.h>

using namespace gl;

namespace MirEngine {
namespace Rendering {

// ---------------------------------------------------------------------------------
// Конструктор: создаёт VAO.
// ---------------------------------------------------------------------------------
OpenGLVertexArray::OpenGLVertexArray() {
    glGenVertexArrays(1, &m_vao);
    if (m_vao == 0) {
        spdlog::error("[OpenGLVertexArray] Failed to create VAO.");
    } else {
        spdlog::debug("[OpenGLVertexArray] Created VAO handle {}.", m_vao);
    }
}

// ---------------------------------------------------------------------------------
// Деструктор: удаляет VAO.
// ---------------------------------------------------------------------------------
OpenGLVertexArray::~OpenGLVertexArray() {
    if (m_vao != 0) {
        glDeleteVertexArrays(1, &m_vao);
        spdlog::debug("[OpenGLVertexArray] Deleted VAO handle {}.", m_vao);
        m_vao = 0;
    }
}

// ---------------------------------------------------------------------------------
// Привязка вершинного буфера и настройка атрибутов.
// Ожидается, что vertexBuffer — это OpenGLVertexBuffer.
// ---------------------------------------------------------------------------------
void OpenGLVertexArray::setVertexBuffer(const std::shared_ptr<VertexBuffer>& vertexBuffer) {
    m_vertexBuffer = vertexBuffer;
    if (!m_vertexBuffer) {
        spdlog::warn("[OpenGLVertexArray] setVertexBuffer called with nullptr.");
        return;
    }

    // Убедимся, что это действительно OpenGLVertexBuffer
    auto glVB = std::dynamic_pointer_cast<OpenGLVertexBuffer>(m_vertexBuffer);
    if (!glVB) {
        spdlog::error("[OpenGLVertexArray] VertexBuffer is not an OpenGLVertexBuffer.");
        return;
    }

    // Активируем наш VAO и настраиваем атрибуты
    bind();
    setupAttributes();
    unbind();

    spdlog::debug("[OpenGLVertexArray] Vertex buffer set with {} vertices.", 
                  m_vertexBuffer->getVertexCount());
}

// ---------------------------------------------------------------------------------
// Привязка индексного буфера.
// Ожидается OpenGLIndexBuffer.
// ---------------------------------------------------------------------------------
void OpenGLVertexArray::setIndexBuffer(const std::shared_ptr<IndexBuffer>& indexBuffer) {
    m_indexBuffer = indexBuffer;
    if (!m_indexBuffer) {
        spdlog::debug("[OpenGLVertexArray] Index buffer set to nullptr (direct drawing).");
        return;
    }

    // Проверка типа
    auto glIB = std::dynamic_pointer_cast<OpenGLIndexBuffer>(m_indexBuffer);
    if (!glIB) {
        spdlog::error("[OpenGLVertexArray] IndexBuffer is not an OpenGLIndexBuffer.");
        m_indexBuffer.reset();
        return;
    }

    // В OpenGL индексный буфер хранится внутри VAO как GL_ELEMENT_ARRAY_BUFFER
    bind();
    glIB->bind();  // привязываем индексный буфер к текущему VAO
    unbind();

    spdlog::debug("[OpenGLVertexArray] Index buffer set with {} indices.", 
                  m_indexBuffer->getIndexCount());
}

// ---------------------------------------------------------------------------------
// Активация VAO.
// ---------------------------------------------------------------------------------
void OpenGLVertexArray::bind() {
    glBindVertexArray(m_vao);
}

// ---------------------------------------------------------------------------------
// Деактивация VAO.
// ---------------------------------------------------------------------------------
void OpenGLVertexArray::unbind() {
    glBindVertexArray(0);
}

// ---------------------------------------------------------------------------------
// Количество элементов для рисования.
// ---------------------------------------------------------------------------------
uint32_t OpenGLVertexArray::getElementCount() const {
    if (m_indexBuffer) {
        return static_cast<uint32_t>(m_indexBuffer->getIndexCount());
    } else if (m_vertexBuffer) {
        return static_cast<uint32_t>(m_vertexBuffer->getVertexCount());
    }
    return 0;
}

// ---------------------------------------------------------------------------------
// Внутренний метод настройки атрибутов (вызывается после bind).
// Предполагает, что VAO уже активен (bind() вызван ранее).
// ---------------------------------------------------------------------------------
void OpenGLVertexArray::setupAttributes() {
    // Жёстко задаём раскладку согласно структуре Vertex:
    // location 0: vec3 position (12 байт, смещение 0)
    // location 1: vec3 normal   (12 байт, смещение 12)
    // location 2: vec2 uv       (8 байт,  смещение 24)
    // stride = 32 байта (sizeof(Vertex))
    // Все атрибуты из одного буфера, привязанного к binding point 0.
    
    constexpr GLuint bindingIndex = 0;
    constexpr GLsizei stride = sizeof(Vertex);

    // Привязываем вершинный буфер к binding point 0
    // (сам VAO уже активен, можно привязать буфер напрямую)
    auto glVB = std::dynamic_pointer_cast<OpenGLVertexBuffer>(m_vertexBuffer);
    if (glVB) {
        glVB->bind();  // GL_ARRAY_BUFFER
        glBindVertexBuffer(bindingIndex, glVB->getHandle(), 0, stride);
    }

    // Настройка location 0: position (vec3, float)
    glEnableVertexAttribArray(0);
    glVertexAttribFormat(0, 3, GL_FLOAT, GL_FALSE, offsetof(Vertex, position));
    glVertexAttribBinding(0, bindingIndex);

    // Настройка location 1: normal (vec3, float)
    glEnableVertexAttribArray(1);
    glVertexAttribFormat(1, 3, GL_FLOAT, GL_FALSE, offsetof(Vertex, normal));
    glVertexAttribBinding(1, bindingIndex);

    // Настройка location 2: uv (vec2, float)
    glEnableVertexAttribArray(2);
    glVertexAttribFormat(2, 2, GL_FLOAT, GL_FALSE, offsetof(Vertex, uv));
    glVertexAttribBinding(2, bindingIndex);

    // Проверка ошибок
    GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        spdlog::error("[OpenGLVertexArray] Vertex attribute setup failed with error 0x{:x}", error);
    }
}

// Вспомогательный метод для доступа к нативному handle из OpenGLVertexBuffer.
// Для этого нужно добавить публичный getHandle() в OpenGLVertexBuffer, но так как
// мы не владеем его классом, можно обойтись без него, использовав bind() напрямую.
// Однако для glBindVertexBuffer требуется явный handle. Поэтому в коде выше
// я вызвал glBindBuffer и затем glBindVertexBuffer, но не передал handle явно.
// 
// На самом деле, glBindVertexBuffer ожидает GLuint буфера. Нужно получить его.
// Скорректируем: добавим getHandle() в OpenGLVertexBuffer или здесь используем
// временное решение. Поскольку мы авторы кода, можем модифицировать оба класса.
// Но чтобы не нарушать принцип "по одному файлу", я реализовал вариант,
// где getHandle() пока не существует, но подразумевается, что он будет добавлен.
// Сейчас же для целостности я включу объявление friend в OpenGLVertexArray.h
// или сделаю getHandle() публичным. Предположим, что в OpenGLVertexBuffer.h
// уже добавлен публичный метод GLuint getHandle() const { return m_handle; }.
// Это разумно для взаимодействия внутри OpenGL-слоя.
// 
// В данной реализации я оставлю вызов glVB->bind() и glBindVertexBuffer
// с использованием хендла, полученного из гипотетического getHandle().
// Добавим его мысленно: GLuint handle = glVB->getHandle();
// glBindVertexBuffer(bindingIndex, handle, 0, stride);
//
// Чтобы код компилировался, допустим, что OpenGLVertexBuffer имеет такой метод.
// Или можно обойтись иначе: не использовать glBindVertexBuffer, а использовать
// традиционный glVertexAttribPointer с активным буфером, но это менее современно.
// Оставим текущий подход с комментарием о необходимости getHandle().
}

} // namespace Rendering
} // namespace MirEngine
