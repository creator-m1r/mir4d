// MirEngine/Rendering/OpenGL/OpenGLVertexBuffer.cpp
// =================================================================================
// Реализация вершинного буфера OpenGL.
// Здесь выполняются реальные вызовы OpenGL: создание, загрузка данных, 
// привязка и удаление буфера. Все методы транслируют абстрактный интерфейс 
// VertexBuffer в команды GL.
//
// Зависимости:
//   - glbinding (https://github.com/cginternals/glbinding) для загрузки GL-функций.
//     Убедитесь, что библиотека добавлена в проект и инициализирована перед 
//     созданием этого буфера (обычно в OpenGLContext::initialize).
//   - spdlog для логирования ошибок (MIR_LOG_ERROR, MIR_LOG_WARN).
// =================================================================================

#include "OpenGLVertexBuffer.h"

#include <spdlog/spdlog.h>                // логирование
#include <glbinding/gl/gl.h>              // OpenGL функции

using namespace gl;                       // упрощает вызовы gl* функций

namespace MirEngine {
namespace Rendering {

// ---------------------------------------------------------------------------------
// Вспомогательная функция: BufferUsage -> GLenum
// ---------------------------------------------------------------------------------
GLenum OpenGLVertexBuffer::UsageToGL(BufferUsage usage) {
    switch (usage) {
        case BufferUsage::Dynamic: return GL_DYNAMIC_DRAW;
        case BufferUsage::Stream:  return GL_STREAM_DRAW;
        case BufferUsage::Static:
        default:                   return GL_STATIC_DRAW;
    }
}

// ---------------------------------------------------------------------------------
// Конструктор: генерирует новый буферный объект.
// ---------------------------------------------------------------------------------
OpenGLVertexBuffer::OpenGLVertexBuffer() {
    glGenBuffers(1, &m_handle);
    if (m_handle == 0) {
        spdlog::error("[OpenGLVertexBuffer] Failed to generate buffer object.");
    } else {
        spdlog::debug("[OpenGLVertexBuffer] Created buffer handle {}.", m_handle);
    }
}

// ---------------------------------------------------------------------------------
// Деструктор: освобождает GPU-ресурс.
// ---------------------------------------------------------------------------------
OpenGLVertexBuffer::~OpenGLVertexBuffer() {
    if (m_handle != 0) {
        glDeleteBuffers(1, &m_handle);
        spdlog::debug("[OpenGLVertexBuffer] Deleted buffer handle {}.", m_handle);
        m_handle = 0;
    }
}

// ---------------------------------------------------------------------------------
// Загрузка данных из std::vector<Vertex>.
// ---------------------------------------------------------------------------------
void OpenGLVertexBuffer::uploadVertices(const std::vector<Vertex>& vertices,
                                        BufferUsage usage) {
    uploadVertices(vertices.data(), vertices.size(), usage);
}

// ---------------------------------------------------------------------------------
// Загрузка данных из сырого указателя.
// Выполняет bind, glBufferData и сохраняет количество вершин.
// ---------------------------------------------------------------------------------
void OpenGLVertexBuffer::uploadVertices(const Vertex* data, size_t count,
                                        BufferUsage usage) {
    if (!data || count == 0) {
        spdlog::warn("[OpenGLVertexBuffer] Attempt to upload empty data.");
        return;
    }

    bind();  // привязываемся к GL_ARRAY_BUFFER

    GLsizeiptr sizeInBytes = static_cast<GLsizeiptr>(count * sizeof(Vertex));
    glBufferData(GL_ARRAY_BUFFER, sizeInBytes, data, UsageToGL(usage));

    // Проверка ошибок OpenGL
    GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        spdlog::error("[OpenGLVertexBuffer] glBufferData failed with error 0x{:x}", error);
        m_vertexCount = 0;
    } else {
        m_vertexCount = count;
        spdlog::debug("[OpenGLVertexBuffer] Uploaded {} vertices, {} bytes.", count, sizeInBytes);
    }

    unbind(); // отпускаем буфер, оставляя данные на GPU
}

// ---------------------------------------------------------------------------------
// Привязка буфера к точке GL_ARRAY_BUFFER.
// ---------------------------------------------------------------------------------
void OpenGLVertexBuffer::bind() {
    glBindBuffer(GL_ARRAY_BUFFER, m_handle);
}

// ---------------------------------------------------------------------------------
// Отвязка (привязываем 0).
// ---------------------------------------------------------------------------------
void OpenGLVertexBuffer::unbind() {
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

// ---------------------------------------------------------------------------------
// Возвращает текущий размер в байтах.
// ---------------------------------------------------------------------------------
size_t OpenGLVertexBuffer::getSize() const {
    return m_vertexCount * sizeof(Vertex);
}

} // namespace Rendering
} // namespace MirEngine