// MirEngine/Rendering/OpenGL/OpenGLCapabilities.cpp
// =================================================================================
// Реализация сбора информации о GPU.
// =================================================================================

#include "OpenGLCapabilities.h"

#include <spdlog/spdlog.h>
#include <glbinding/gl/gl.h>
#include <glbinding/gl/enum.h>
#include <sstream>

using namespace gl;

namespace MirEngine {
namespace Rendering {

CapabilitiesInfo OpenGLCapabilities::query() {
    CapabilitiesInfo info;

    // Базовые строки
    const GLubyte* vendor = glGetString(GL_VENDOR);
    const GLubyte* renderer = glGetString(GL_RENDERER);
    const GLubyte* version = glGetString(GL_VERSION);
    const GLubyte* shading = glGetString(GL_SHADING_LANGUAGE_VERSION);

    info.vendor   = vendor   ? reinterpret_cast<const char*>(vendor)   : "Unknown";
    info.renderer = renderer ? reinterpret_cast<const char*>(renderer) : "Unknown";
    info.version  = version  ? reinterpret_cast<const char*>(version)  : "Unknown";
    info.shadingLanguageVersion = shading ? reinterpret_cast<const char*>(shading) : "Unknown";

    // Числовые лимиты
    glGetIntegerv(GL_MAX_TEXTURE_SIZE, &info.maxTextureSize);
    glGetIntegerv(GL_MAX_SAMPLES, &info.maxSamples);

    // Анизотропная фильтрация
    info.anisotropySupported = isExtensionSupported("GL_EXT_texture_filter_anisotropic") ||
                               isExtensionSupported("GL_ARB_texture_filter_anisotropic");
    if (info.anisotropySupported) {
        glGetIntegerv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &info.maxAnisotropy);
    }

    // Расширения (OpenGL 4.1: список через пробел)
    GLint numExtensions = 0;
    glGetIntegerv(GL_NUM_EXTENSIONS, &numExtensions);
    for (GLint i = 0; i < numExtensions; ++i) {
        const GLubyte* ext = glGetStringi(GL_EXTENSIONS, i);
        if (ext) info.extensions.push_back(reinterpret_cast<const char*>(ext));
    }

    // Логируем основное
    spdlog::info("[OpenGLCapabilities] Vendor: {}", info.vendor);
    spdlog::info("[OpenGLCapabilities] Renderer: {}", info.renderer);
    spdlog::info("[OpenGLCapabilities] Version: {}", info.version);
    spdlog::info("[OpenGLCapabilities] GLSL: {}", info.shadingLanguageVersion);
    spdlog::info("[OpenGLCapabilities] Max Texture Size: {}", info.maxTextureSize);
    spdlog::info("[OpenGLCapabilities] Max Samples: {}", info.maxSamples);
    spdlog::info("[OpenGLCapabilities] Anisotropy: {} (max {})", info.anisotropySupported ? "yes" : "no", info.maxAnisotropy);
    spdlog::info("[OpenGLCapabilities] Extensions loaded: {}", info.extensions.size());

    return info;
}

bool OpenGLCapabilities::isExtensionSupported(const std::string& name) {
    GLint numExt = 0;
    glGetIntegerv(GL_NUM_EXTENSIONS, &numExt);
    for (GLint i = 0; i < numExt; ++i) {
        const GLubyte* ext = glGetStringi(GL_EXTENSIONS, i);
        if (ext && name == reinterpret_cast<const char*>(ext)) {
            return true;
        }
    }
    return false;
}

} // namespace Rendering
} // namespace MirEngine