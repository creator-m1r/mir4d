#include "OpenGLDevice.h"
#include "OpenGLContext.h"

namespace MirEngine::Rendering {

OpenGLDevice::OpenGLDevice(
    OpenGLContext* context)
    : m_context(context)
{
}

bool OpenGLDevice::initialize()
{
    if (!m_context) {
        return false;
    }

    m_context->makeCurrent();

    m_state.initialize();

    auto size = m_context->size();

    m_state.setViewport(
        size.width,
        size.height
    );

    return true;
}

void OpenGLDevice::beginFrame()
{
    m_context->makeCurrent();

    m_state.beginFrame();
}

void OpenGLDevice::endFrame()
{
    m_state.endFrame();

    m_context->swapBuffers();
}

void OpenGLDevice::resize(
    uint32_t width,
    uint32_t height)
{
    m_context->resize(
        { width, height }
    );

    m_state.setViewport(
        width,
        height
    );
}

OpenGLContext*
OpenGLDevice::context() const
{
    return m_context;
}

}