// MirEngine/Rendering/OpenGL/OpenGLDevice.h
#pragma once

#include "OpenGLState.h"

namespace MirEngine::Rendering {

class OpenGLContext;

class OpenGLDevice {
public:

    explicit OpenGLDevice(OpenGLContext* context);

    bool initialize();

    void beginFrame();

    void endFrame();

    void resize(
        uint32_t width,
        uint32_t height
    );

    OpenGLContext* context() const;

private:

    OpenGLContext* m_context = nullptr;

    OpenGLState m_state;
};

}