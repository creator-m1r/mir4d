#pragma once

#include <memory>

namespace MirEngine::Rendering {

class OpenGLContext;
class OpenGLDevice;

class OpenGLRenderer {
public:

    explicit OpenGLRenderer(
        OpenGLContext* context
    );

    ~OpenGLRenderer();

    bool initialize();

    void render();

    void resize(
        uint32_t width,
        uint32_t height
    );

private:

    OpenGLContext* m_context = nullptr;

    std::unique_ptr<OpenGLDevice>
        m_device;

    bool m_initialized = false;
};

}