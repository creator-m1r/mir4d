// MirEngine/Rendering/OpenGL/OpenGLDebug.cpp
// =================================================================================
// Реализация отладочных утилит OpenGL.
// Использует glGetError и GL_KHR_debug для мониторинга состояния GPU.
// =================================================================================

#include "OpenGLDebug.h"

#include <spdlog/spdlog.h>
#include <glbinding/gl/gl.h>
#include <glbinding/gl/enum.h>

using namespace gl;

namespace MirEngine {
namespace Rendering {

// ---------------------------------------------------------------------------------
// Проверка glGetError и логирование
// ---------------------------------------------------------------------------------
bool OpenGLDebug::checkError(const std::string& context)
{
GLenum error = glGetError();
if (error == GL_NO_ERROR) {
return true;
}

// Собираем все накопившиеся ошибки
while (error != GL_NO_ERROR) {
std::string errorStr;
switch (error) {
case GL_INVALID_ENUM: errorStr = "GL_INVALID_ENUM"; break;
case GL_INVALID_VALUE: errorStr = "GL_INVALID_VALUE"; break;
case GL_INVALID_OPERATION: errorStr = "GL_INVALID_OPERATION"; break;
case GL_STACK_OVERFLOW: errorStr = "GL_STACK_OVERFLOW"; break;
case GL_STACK_UNDERFLOW: errorStr = "GL_STACK_UNDERFLOW"; break;
case GL_OUT_OF_MEMORY: errorStr = "GL_OUT_OF_MEMORY"; break;
case GL_INVALID_FRAMEBUFFER_OPERATION: errorStr = "GL_INVALID_FRAMEBUFFER_OPERATION"; break;
default: errorStr = fmt::format("0x{:x}", static_cast<unsigned>(error)); break;
}
spdlog::error("[GL Debug] {}: {}", context, errorStr);
error = glGetError();
}
return false;
}

// ---------------------------------------------------------------------------------
// Callback для отладочных сообщений драйвера
// ---------------------------------------------------------------------------------
void GLAPIENTRY OpenGLDebug::debugCallback(GLenum source,
GLenum type,
GLuint id,
GLenum severity,
GLsizei /length/,
const GLchar* message,
const void* /userParam/)
{
// Преобразуем source и type в строки для читаемости
std::string sourceStr;
switch (source) {
case GL_DEBUG_SOURCE_API: sourceStr = "API"; break;
case GL_DEBUG_SOURCE_WINDOW_SYSTEM: sourceStr = "Window System"; break;
case GL_DEBUG_SOURCE_SHADER_COMPILER: sourceStr = "Shader Compiler"; break;
case GL_DEBUG_SOURCE_THIRD_PARTY: sourceStr = "Third Party"; break;
case GL_DEBUG_SOURCE_APPLICATION: sourceStr = "Application"; break;
case GL_DEBUG_SOURCE_OTHER: sourceStr = "Other"; break;
default: sourceStr = "Unknown"; break;
}

std::string typeStr;
switch (type) {
case GL_DEBUG_TYPE_ERROR: typeStr = "Error"; break;
case GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR: typeStr = "Deprecated Behavior"; break;
case GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR: typeStr = "Undefined Behavior"; break;
case GL_DEBUG_TYPE_PORTABILITY: typeStr = "Portability"; break;
case GL_DEBUG_TYPE_PERFORMANCE: typeStr = "Performance"; break;
case GL_DEBUG_TYPE_MARKER: typeStr = "Marker"; break;
case GL_DEBUG_TYPE_PUSH_GROUP: typeStr = "Push Group"; break;
case GL_DEBUG_TYPE_POP_GROUP: typeStr = "Pop Group"; break;
case GL_DEBUG_TYPE_OTHER: typeStr = "Other"; break;
default: typeStr = "Unknown"; break;
}

// Логируем в зависимости от severity
if (severity == GL_DEBUG_SEVERITY_HIGH) {
spdlog::error("[GL Debug] {} ({}): {} (id={})", sourceStr, typeStr, message, id);
} else if (severity == GL_DEBUG_SEVERITY_MEDIUM) {
spdlog::warn("[GL Debug] {} ({}): {} (id={})", sourceStr, typeStr, message, id);
} else if (severity == GL_DEBUG_SEVERITY_LOW) {
spdlog::info("[GL Debug] {} ({}): {} (id={})", sourceStr, typeStr, message, id);
} else {
spdlog::debug("[GL Debug] {} ({}): {} (id={})", sourceStr, typeStr, message, id);
}
}

// ---------------------------------------------------------------------------------
// Включение синхронного вывода отладки драйвера
// ---------------------------------------------------------------------------------
bool OpenGLDebug::enableDebugOutput()
{
// Проверяем наличие расширения GL_KHR_debug (в OpenGL 4.3 оно часть ядра, но 4.1 может иметь)
// Используем glbinding для проверки наличия функции
if (!glbinding::Binding::isFunctionAvailable("glDebugMessageCallback")) {
spdlog::warn("[OpenGLDebug] glDebugMessageCallback not available; debug output disabled.");
return false;
}

glEnable(GL_DEBUG_OUTPUT);
glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS); // синхронный вывод для точного стека вызовов
glDebugMessageCallback(&debugCallback, nullptr);

// Фильтр: выводим все сообщения
glDebugMessageControl(GL_DONT_CARE, GL_DONT_CARE, GL_DONT_CARE, 0, nullptr, GL_TRUE);

spdlog::info("[OpenGLDebug] Debug output enabled.");
return true;
}

} // namespace Rendering
} // namespace MirEngine