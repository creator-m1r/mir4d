// MirEngine/Rendering/OpenGL/OpenGLDebug.h
// =================================================================================
// Утилита отладки OpenGL.
//
// Предоставляет статические методы для проверки ошибок после вызовов GL-функций
// (checkError) и для включения синхронного вывода отладочных сообщений драйвера
// (enableDebugOutput). Вся функциональность реализована через glbinding и
// стандартный механизм GL_KHR_debug (OpenGL 4.3+), который доступен в 4.1
// через расширение.
//
// Архитектура:
//   - Не имеет состояния (все методы статические) для простоты использования.
//   - Вызывается из любого места OpenGL-слоя после подозрительных вызовов.
//   - Логирует ошибки и предупреждения через spdlog с префиксом [GL Debug].
//
// Использование:
//   OpenGLDebug::enableDebugOutput(); // в начале инициализации
//   ...
//   glSomeCall();
//   OpenGLDebug::checkError("after glSomeCall");
// =================================================================================

#pragma once

#include <string>
#include <glbinding/gl/gl.h>

namespace MirEngine {
namespace Rendering {

class OpenGLDebug {
public:
    // --------------------------------------------------------------------------
    // Проверяет наличие ошибок GL (glGetError) и логирует их с переданным
    // контекстным сообщением. Возвращает true, если ошибок не было.
    // --------------------------------------------------------------------------
    static bool checkError(const std::string& context = "");

    // --------------------------------------------------------------------------
    // Включает синхронный вывод отладочных сообщений от драйвера OpenGL.
    // Работает через GL_KHR_debug. Сообщения выводятся в spdlog с уровнями
    // в зависимости от severity (notification -> info, warning -> warn, error -> error).
    // Для работы требуется поддержка расширения драйвером (обычно есть).
    // Возвращает true, если включено успешно.
    // --------------------------------------------------------------------------
    static bool enableDebugOutput();

private:
    // Callback для glDebugMessageCallback
    static void GLAPIENTRY debugCallback(gl::GLenum source,
                                        gl::GLenum type,
                                        gl::GLuint id,
                                        gl::GLenum severity,
                                        gl::GLsizei length,
                                        const gl::GLchar* message,
                                        const void* userParam);
};

} // namespace Rendering
} // namespace MirEngine