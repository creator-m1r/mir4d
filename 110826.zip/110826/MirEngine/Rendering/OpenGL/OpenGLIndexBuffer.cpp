// MirEngine/Rendering/OpenGL/OpenGLIndexBuffer.cpp
// =================================================================================
// Реализация индексного буфера OpenGL.
// Инкапсулирует работу с GL_ELEMENT_ARRAY_BUFFER: создание, загрузку данных,
// привязку и удаление. Все вызовы gl* находятся здесь, изолируя остальной
// движок от знания о конкретном API.
//
// Зависимости:
//   - glbinding (OpenGL-функции)
//   - spdlog (логирование ошибок и отладки)
// =================================================================================

#include "OpenGLIndexBuffer.h"

#include <spdlog/spdlog.h>
#include <glbinding/gl/gl.h>

using namespace gl;

namespace MirEngine {
namespace Rendering {

// ---------------------------------------------------------------------------------
// Преобразование BufferUsage -> GLenum
// ---------------------------------------------------------------------------------
GLenum OpenGLIndexBuffer::UsageToGL(BufferUsage usage) {
    switch (usage) {
        case BufferUsage::Dynamic: return GL_DYNAMIC_DRAW;
        case BufferUsage::Stream:  return GL_STREAM_DRAW;
        case BufferUsage::Static:
        default:                   return GL_STATIC_DRAW;
    }
}

// ---------------------------------------------------------------------------------
// Конструктор: генерирует новый буферный объект.
// ---------------------------------------------------------------------------------
OpenGLIndexBuffer::OpenGLIndexBuffer() {
    glGenBuffers(1, &m_handle);
    if (m_handle == 0) {
        spdlog::error("[OpenGLIndexBuffer] Failed to generate buffer object.");
    } else {
        spdlog::debug("[OpenGLIndexBuffer] Created buffer handle {}.", m_handle);
    }
}

// ---------------------------------------------------------------------------------
// Деструктор: освобождает GPU-ресурс.
// ---------------------------------------------------------------------------------
OpenGLIndexBuffer::~OpenGLIndexBuffer() {
    if (m_handle != 0) {
        glDeleteBuffers(1, &m_handle);
        spdlog::debug("[OpenGLIndexBuffer] Deleted buffer handle {}.", m_handle);
        m_handle = 0;
    }
}

// ---------------------------------------------------------------------------------
// Загрузка индексов из std::vector<uint32_t>.
// ---------------------------------------------------------------------------------
void OpenGLIndexBuffer::uploadIndices(const std::vector<uint32_t>& indices,
                                      BufferUsage usage) {
    uploadIndices(indices.data(), indices.size(), usage);
}

// ---------------------------------------------------------------------------------
// Загрузка индексов из сырого указателя + количество.
// Выполняет bind, glBufferData и сохраняет количество индексов.
// ---------------------------------------------------------------------------------
void OpenGLIndexBuffer::uploadIndices(const uint32_t* data, size_t count,
                                      BufferUsage usage) {
    if (!data || count == 0) {
        spdlog::warn("[OpenGLIndexBuffer] Attempt to upload empty or null data.");
        return;
    }

    bind();  // привязываемся к GL_ELEMENT_ARRAY_BUFFER

    GLsizeiptr sizeInBytes = static_cast<GLsizeiptr>(count * sizeof(uint32_t));
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeInBytes, data, UsageToGL(usage));

    GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        spdlog::error("[OpenGLIndexBuffer] glBufferData failed with error 0x{:x}", error);
        m_indexCount = 0;
    } else {
        m_indexCount = count;
        spdlog::debug("[OpenGLIndexBuffer] Uploaded {} indices, {} bytes.", count, sizeInBytes);
    }

    unbind(); // отпускаем буфер
}

// ---------------------------------------------------------------------------------
// Привязка буфера к GL_ELEMENT_ARRAY_BUFFER.
// ---------------------------------------------------------------------------------
void OpenGLIndexBuffer::bind() {
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_handle);
}

// ---------------------------------------------------------------------------------
// Отвязка (привязываем 0).
// ---------------------------------------------------------------------------------
void OpenGLIndexBuffer::unbind() {
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

// ---------------------------------------------------------------------------------
// Возвращает текущий размер в байтах.
// ---------------------------------------------------------------------------------
size_t OpenGLIndexBuffer::getSize() const {
    return m_indexCount * sizeof(uint32_t);
}

} // namespace Rendering
} // namespace MirEngine