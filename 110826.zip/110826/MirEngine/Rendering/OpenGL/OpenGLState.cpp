#include "OpenGLState.h"

#include <OpenGL/gl3.h>

namespace MirEngine::Rendering {

void OpenGLState::initialize()
{
    glEnable(GL_DEPTH_TEST);

    glDepthFunc(GL_LESS);

    glEnable(GL_CULL_FACE);

    glCullFace(GL_BACK);

    glClearDepth(1.0);
}

void OpenGLState::setViewport(
    uint32_t width,
    uint32_t height)
{
    glViewport(
        0,
        0,
        static_cast<GLsizei>(width),
        static_cast<GLsizei>(height)
    );
}

void OpenGLState::beginFrame()
{
    glClear(
        GL_COLOR_BUFFER_BIT |
        GL_DEPTH_BUFFER_BIT |
        GL_STENCIL_BUFFER_BIT
    );
}

void OpenGLState::endFrame()
{
    glFlush();
}

}