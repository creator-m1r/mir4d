// MirEngine/Rendering/OpenGL/OpenGLShader.cpp
// =================================================================================
// Реализация шейдерной программы OpenGL.
//
// Выполняет компиляцию вершинного и фрагментного шейдеров из исходного кода GLSL,
// линковку программы и предоставляет методы для установки uniform-переменных.
// Все вызовы gl* изолированы здесь; остальной движок работает через интерфейс Shader.
//
// Зависимости:
//   - glbinding (OpenGL-функции)
//   - spdlog   (логирование ошибок и отладки)
// =================================================================================

#include "OpenGLShader.h"

#include <spdlog/spdlog.h>
#include <glbinding/gl/gl.h>
#include <array>

using namespace gl;

namespace MirEngine {
namespace Rendering {

// ---------------------------------------------------------------------------------
// Конструктор: создаёт пустую программу (пока без шейдеров).
// ---------------------------------------------------------------------------------
OpenGLShader::OpenGLShader() {
    m_program = glCreateProgram();
    if (m_program == 0) {
        spdlog::error("[OpenGLShader] Failed to create shader program.");
    } else {
        spdlog::debug("[OpenGLShader] Created program handle {}.", m_program);
    }
}

// ---------------------------------------------------------------------------------
// Деструктор: удаляет программу и очищает кэш uniform-локаций.
// ---------------------------------------------------------------------------------
OpenGLShader::~OpenGLShader() {
    if (m_program != 0) {
        glDeleteProgram(m_program);
        spdlog::debug("[OpenGLShader] Deleted program handle {}.", m_program);
        m_program = 0;
    }
    m_uniformCache.clear();
}

// ---------------------------------------------------------------------------------
// Компиляция вершинного и фрагментного шейдеров из строк GLSL.
// При успехе возвращает true; при ошибках компиляции/линковки — false.
// Внутри создаёт временные шейдерные объекты, удаляя их после линковки.
// ---------------------------------------------------------------------------------
bool OpenGLShader::compile(const std::string& vertexSource,
                           const std::string& fragmentSource) {
    if (m_program != 0) {
        // Если программа уже существует, удалим её перед созданием новой
        glDeleteProgram(m_program);
        m_program = 0;
        m_uniformCache.clear();
    }

    m_program = glCreateProgram();
    if (m_program == 0) {
        spdlog::error("[OpenGLShader] Failed to create new program during compile.");
        return false;
    }

    // Компилируем вершинный шейдер
    GLuint vs = compileShader(GL_VERTEX_SHADER, vertexSource);
    if (vs == 0) {
        glDeleteProgram(m_program);
        m_program = 0;
        return false;
    }

    // Компилируем фрагментный шейдер
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, fragmentSource);
    if (fs == 0) {
        glDeleteShader(vs);
        glDeleteProgram(m_program);
        m_program = 0;
        return false;
    }

    // Прикрепляем шейдеры к программе
    glAttachShader(m_program, vs);
    glAttachShader(m_program, fs);

    // Линкуем программу
    glLinkProgram(m_program);

    // Проверяем статус линковки
    GLint linkStatus = 0;
    glGetProgramiv(m_program, GL_LINK_STATUS, &linkStatus);
    if (linkStatus == GL_FALSE) {
        GLint logLength = 0;
        glGetProgramiv(m_program, GL_INFO_LOG_LENGTH, &logLength);
        if (logLength > 0) {
            std::vector<char> log(static_cast<size_t>(logLength) + 1);
            glGetProgramInfoLog(m_program, logLength, nullptr, log.data());
            spdlog::error("[OpenGLShader] Program linking failed:\n{}", log.data());
        } else {
            spdlog::error("[OpenGLShader] Program linking failed (no log available).");
        }

        // Удаляем временные объекты
        glDeleteShader(vs);
        glDeleteShader(fs);
        glDeleteProgram(m_program);
        m_program = 0;
        return false;
    }

    // Линковка успешна: можно удалять промежуточные шейдеры
    glDeleteShader(vs);
    glDeleteShader(fs);

    spdlog::info("[OpenGLShader] Shader compiled and linked successfully (program {})", m_program);
    return true;
}

// ---------------------------------------------------------------------------------
// Активация программы (glUseProgram).
// ---------------------------------------------------------------------------------
void OpenGLShader::bind() {
    glUseProgram(m_program);
}

// ---------------------------------------------------------------------------------
// Деактивация программы.
// ---------------------------------------------------------------------------------
void OpenGLShader::unbind() {
    glUseProgram(0);
}

// ---------------------------------------------------------------------------------
// Установка целочисленной uniform-переменной.
// ---------------------------------------------------------------------------------
void OpenGLShader::setInt(std::string_view name, int value) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniform1i(location, value);
    }
}

// ---------------------------------------------------------------------------------
// Установка float-переменной.
// ---------------------------------------------------------------------------------
void OpenGLShader::setFloat(std::string_view name, float value) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniform1f(location, value);
    }
}

// ---------------------------------------------------------------------------------
// Установка vec2.
// ---------------------------------------------------------------------------------
void OpenGLShader::setVec2(std::string_view name, float x, float y) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniform2f(location, x, y);
    }
}

// ---------------------------------------------------------------------------------
// Установка vec3.
// ---------------------------------------------------------------------------------
void OpenGLShader::setVec3(std::string_view name, float x, float y, float z) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniform3f(location, x, y, z);
    }
}

// ---------------------------------------------------------------------------------
// Установка vec4.
// ---------------------------------------------------------------------------------
void OpenGLShader::setVec4(std::string_view name, float x, float y, float z, float w) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniform4f(location, x, y, z, w);
    }
}

// ---------------------------------------------------------------------------------
// Установка матрицы 4×4 (column-major, как принято в OpenGL).
// ---------------------------------------------------------------------------------
void OpenGLShader::setMatrix(std::string_view name, const Matrix4Raw& matrix) {
    GLint location = getUniformLocation(name);
    if (location != -1) {
        glUniformMatrix4fv(location, 1, GL_FALSE, matrix.data());
    }
}

// ---------------------------------------------------------------------------------
// Внутренний метод: получение location uniform'а с кэшированием.
// Если uniform не найден, возвращает -1 и логирует предупреждение.
// ---------------------------------------------------------------------------------
GLint OpenGLShader::getUniformLocation(std::string_view name) {
    std::string key(name);
    auto it = m_uniformCache.find(key);
    if (it != m_uniformCache.end()) {
        return it->second;
    }

    if (m_program == 0) {
        spdlog::warn("[OpenGLShader] Attempt to get uniform '{}' on invalid program.", key);
        return -1;
    }

    GLint location = glGetUniformLocation(m_program, key.c_str());
    if (location == -1) {
        spdlog::warn("[OpenGLShader] Uniform '{}' not found in program {}.", key, m_program);
    } else {
        spdlog::debug("[OpenGLShader] Cached uniform '{}' at location {}.", key, location);
        m_uniformCache[key] = location;
    }
    return location;
}

// ---------------------------------------------------------------------------------
// Компилирует отдельный шейдер заданного типа.
// Возвращает handle шейдера или 0 в случае ошибки.
// ---------------------------------------------------------------------------------
GLuint OpenGLShader::compileShader(GLenum type, const std::string& source) {
    GLuint shader = glCreateShader(type);
    if (shader == 0) {
        spdlog::error("[OpenGLShader] Failed to create shader object (type 0x{:x}).", static_cast<unsigned>(type));
        return 0;
    }

    // Передаём исходный код
    const GLchar* srcPtr = source.c_str();
    GLint srcLength = static_cast<GLint>(source.length());
    glShaderSource(shader, 1, &srcPtr, &srcLength);

    // Компилируем
    glCompileShader(shader);

    // Проверяем статус
    if (!checkShaderCompileStatus(shader, 
            (type == GL_VERTEX_SHADER) ? "vertex" : "fragment")) {
        glDeleteShader(shader);
        return 0;
    }

    spdlog::debug("[OpenGLShader] Compiled {} shader successfully.", 
                  (type == GL_VERTEX_SHADER) ? "vertex" : "fragment");
    return shader;
}

// ---------------------------------------------------------------------------------
// Проверяет статус компиляции шейдера и выводит лог при ошибке.
// Возвращает true, если компиляция успешна.
// ---------------------------------------------------------------------------------
bool OpenGLShader::checkShaderCompileStatus(GLuint shader, const char* typeName) {
    GLint compileStatus = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compileStatus);
    if (compileStatus == GL_FALSE) {
        GLint logLength = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
        if (logLength > 0) {
            std::vector<char> log(static_cast<size_t>(logLength) + 1);
            glGetShaderInfoLog(shader, logLength, nullptr, log.data());
            spdlog::error("[OpenGLShader] {} shader compilation failed:\n{}", typeName, log.data());
        } else {
            spdlog::error("[OpenGLShader] {} shader compilation failed (no log available).", typeName);
        }
        return false;
    }
    return true;
}

} // namespace Rendering
} // namespace MirEngine