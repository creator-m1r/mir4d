// MirEngine/Rendering/Passes/GridPass.cpp
// =================================================================================
// Реализация GridPass.
// =================================================================================

#include "GridPass.h"
#include "../Resources/VertexArray.h"
#include "../Resources/VertexBuffer.h"
#include "../Resources/Vertex.h"
#include "../Rendering/Core/RenderContext.h"
#include "../Scene/Camera.h"
#include "../Scene/Scene.h"

#include <spdlog/spdlog.h>

namespace MirEngine {
namespace Rendering {

// Простейший шейдер для одноцветных линий
static const char* kSolidColorVertexShader = R"(
#version 410 core
layout (location = 0) in vec3 aPos;

uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_projection;

void main() {
    gl_Position = u_projection * u_view * u_model * vec4(aPos, 1.0);
}
)";

static const char* kSolidColorFragmentShader = R"(
#version 410 core
out vec4 FragColor;
uniform vec4 u_color;

void main() {
    FragColor = u_color;
}
)";

GridPass::GridPass(ShaderLibrary& shaderLibrary)
    : m_shaderLibrary(shaderLibrary)
{
}

bool GridPass::initialize(RenderDevice& device) {
    // --- Загрузка шейдера ---
    ShaderHandle gridShaderHandle = m_shaderLibrary.load("SolidColor",
                                                         kSolidColorVertexShader,
                                                         kSolidColorFragmentShader);
    if (gridShaderHandle.empty()) {
        spdlog::error("[GridPass] Failed to load SolidColor shader.");
        return false;
    }
    auto shader = m_shaderLibrary.get(gridShaderHandle);
    m_gridMaterialHandle = 1000; // фиксированный дескриптор для сетки
    device.registerMaterial(m_gridMaterialHandle, shader);
    m_axisMaterialHandle = 1001; // дескриптор для осей
    device.registerMaterial(m_axisMaterialHandle, shader);

    // --- Геометрия сетки ---
    buildGridGeometry();
    m_gridVB = device.createVertexBuffer();
    m_gridVB->uploadVertices(m_gridVertices, BufferUsage::Static);
    m_gridVAO = device.createVertexArray();
    m_gridVAO->setVertexBuffer(m_gridVB);
    m_gridMeshHandle = 2000;
    device.registerMesh(m_gridMeshHandle, m_gridVAO);

    // --- Геометрия осей ---
    buildAxesGeometry();
    m_axisVB = device.createVertexBuffer();
    m_axisVB->uploadVertices(m_axisVertices, BufferUsage::Static);
    m_axisVAO = device.createVertexArray();
    m_axisVAO->setVertexBuffer(m_axisVB);
    m_axisMeshHandle = 2001;
    device.registerMesh(m_axisMeshHandle, m_axisVAO);

    spdlog::info("[GridPass] Initialized. Grid: {} vertices, Axes: {} vertices.",
                 m_gridVertices.size(), m_axisVertices.size());
    return true;
}

void GridPass::execute(RenderContext& context,
                       Scene& /*scene*/,
                       Camera& /*camera*/,
                       RenderDevice& device) {
    // Рисуем сетку
    if (m_gridVisible) {
        // Устанавливаем цвет сетки (серый полупрозрачный)
        auto shader = m_shaderLibrary.get("SolidColor");
        if (shader) {
            shader->bind();
            shader->setVec4("u_color", 0.6f, 0.6f, 0.6f, 0.5f);
            // матрицы передаются через устройство (setViewMatrix, setProjectionMatrix),
            // но uniform'ы u_view и u_projection устанавливаются устройством в draw().
            // Здесь мы полагаемся, что устройство уже имеет актуальные матрицы.
        }
        RenderCommand cmd;
        cmd.mesh      = m_gridMeshHandle;
        cmd.material  = m_gridMaterialHandle;
        cmd.modelMatrix = IdentityMatrix4();
        cmd.primitive = PrimitiveType::Lines;
        device.draw(cmd);
    }

    // Рисуем оси
    if (m_axesVisible) {
        auto shader = m_shaderLibrary.get("SolidColor");
        if (shader) shader->bind(); // шейдер уже активен, если не менялся
        RenderCommand cmd;
        cmd.mesh      = m_axisMeshHandle;
        cmd.material  = m_axisMaterialHandle;
        cmd.modelMatrix = IdentityMatrix4();
        cmd.primitive = PrimitiveType::Lines;
        device.draw(cmd);
    }
}

void GridPass::buildGridGeometry() {
    m_gridVertices.clear();
    float extent = m_gridSize * 0.5f;
    int steps = m_gridSubdivisions;
    float step = m_gridStep;

    // Линии параллельно X (Y меняется)
    for (int i = -steps; i <= steps; ++i) {
        float y = i * step;
        m_gridVertices.push_back({{-extent, y, 0.0f}, {0,0,1}, {}});
        m_gridVertices.push_back({{ extent, y, 0.0f}, {0,0,1}, {}});
    }
    // Линии параллельно Y (X меняется)
    for (int i = -steps; i <= steps; ++i) {
        float x = i * step;
        m_gridVertices.push_back({{x, -extent, 0.0f}, {0,0,1}, {}});
        m_gridVertices.push_back({{x,  extent, 0.0f}, {0,0,1}, {}});
    }
}

void GridPass::buildAxesGeometry() {
    m_axisVertices.clear();
    float len = m_gridSize * 0.6f; // оси чуть короче сетки

    // Ось X (красный)
    m_axisVertices.push_back({{-len, 0.0f, 0.0f}, {1,0,0}, {}});
    m_axisVertices.push_back({{ len, 0.0f, 0.0f}, {1,0,0}, {}});
    // Ось Y (зелёный)
    m_axisVertices.push_back({{0.0f, -len, 0.0f}, {0,1,0}, {}});
    m_axisVertices.push_back({{0.0f,  len, 0.0f}, {0,1,0}, {}});
    // Ось Z (синий)
    m_axisVertices.push_back({{0.0f, 0.0f, -len}, {0,0,1}, {}});
    m_axisVertices.push_back({{0.0f, 0.0f,  len}, {0,0,1}, {}});
}

} // namespace Rendering
} // namespace MirEngine