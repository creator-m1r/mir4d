// MirEngine/Rendering/Passes/GridPass.h
// =================================================================================
// Проход рендеринга координатной сетки и осей (Grid Pass).
//
// Отвечает за отрисовку:
//   - XY-сетки на плоскости Z=0 (основная рабочая плоскость CAD).
//   - Трёх цветных осей (X — красный, Y — зелёный, Z — синий) со стрелками.
//   - Подписей осей (будущее расширение).
//
// Сетка строится из линий с учётом текущей камеры: шаг сетки адаптируется к
// расстоянию, чтобы не перегружать сцену мелкими делениями. Сетка рисуется
// полупрозрачной, чтобы не перебивать геометрию.
//
// Архитектура:
//   - Создаёт собственные VAO/VBO для линий сетки и осей при initialize().
//   - Регистрирует их в устройстве под фиксированными дескрипторами.
//   - В execute() формирует RenderCommand с соответствующим материалом и рисует.
//
// Шейдеры:
//   - Использует простой одноцветный шейдер "SolidColor".
//   - Цвет передаётся через uniform.
//
// Изоляция:
//   - Никаких прямых OpenGL-вызовов, только RenderDevice и его интерфейсы.
// =================================================================================

#pragma once

#include "RenderPass.h"
#include "../Core/RenderCommand.h"
#include "../Resources/ShaderLibrary.h"
#include <memory>
#include <vector>

namespace MirEngine {

class Camera;

namespace Rendering {

class RenderDevice;
class RenderContext;
class VertexArray;
class VertexBuffer;

class GridPass : public RenderPass {
public:
    explicit GridPass(ShaderLibrary& shaderLibrary);

    // --------------------------------------------------------------------------
    // Инициализация: создаёт буферы для сетки и осей, загружает шейдер.
    // Вызывается после создания RenderDevice.
    // --------------------------------------------------------------------------
    bool initialize(RenderDevice& device);

    // --------------------------------------------------------------------------
    // Основной метод: рисует сетку и оси.
    // --------------------------------------------------------------------------
    void execute(RenderContext& context,
                 Scene& scene,
                 Camera& camera,
                 RenderDevice& device) override;

    // Управление видимостью
    void setGridVisible(bool visible) { m_gridVisible = visible; }
    void setAxesVisible(bool visible) { m_axesVisible = visible; }

private:
    ShaderLibrary& m_shaderLibrary;

    // Дескрипторы
    MaterialHandle m_gridMaterialHandle = 0;
    MeshHandle     m_gridMeshHandle = 0;
    MaterialHandle m_axisMaterialHandle = 0;
    MeshHandle     m_axisMeshHandle = 0;

    // Ресурсы
    std::shared_ptr<VertexArray>  m_gridVAO;
    std::shared_ptr<VertexBuffer> m_gridVB;
    std::shared_ptr<VertexArray>  m_axisVAO;
    std::shared_ptr<VertexBuffer> m_axisVB;

    bool m_gridVisible = true;
    bool m_axesVisible = true;

    // Размер сетки (будет адаптироваться под камеру)
    float m_gridSize    = 100.0f;
    float m_gridStep    = 10.0f;
    int   m_gridSubdivisions = 10; // количество линий в одном направлении

    // --------------------------------------------------------------------------
    // Генерация геометрии сетки (линии на плоскости XY)
    // --------------------------------------------------------------------------
    void buildGridGeometry();
    // Генерация геометрии осей (линии X, Y, Z с отметками)
    void buildAxesGeometry();
};

} // namespace Rendering
} // namespace MirEngine