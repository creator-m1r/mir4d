// MirEngine/Scene/CameraController.h
// =================================================================================
// Контроллер камеры для орбитального вращения, панорамирования и зума.
//
// Принимает события мыши (нажатие, перемещение, колёсико) и преобразует их
// в изменение параметров орбиты камеры (theta, phi, distance, target).
// Не зависит от платформы — конкретные UI-события транслируются в вызовы методов.
//
// Архитектура:
//   Viewport получает события от MirUI (SwiftUI/WinUI), вызывает методы контроллера.
//   Контроллер обновляет Camera, которая используется при рендеринге кадра.
//
// Управление:
//   - ЛКМ + перемещение = вращение вокруг target (изменение theta и phi).
//   - ПКМ + перемещение = панорамирование (сдвиг target в плоскости экрана).
//   - Колёсико мыши = зум (изменение distance).
// =================================================================================

#pragma once

#include <cmath>
#include <algorithm>

namespace MirEngine {

class Camera;

class CameraController {
public:
    // --------------------------------------------------------------------------
    // Конструктор. Принимает указатель на управляемую камеру.
    // --------------------------------------------------------------------------
    explicit CameraController(Camera* camera);

    // --------------------------------------------------------------------------
    // События мыши (вызываются из Viewport/UI).
    // posX, posY — текущие координаты мыши в пикселях относительно вьюпорта.
    // button: 0 = левая, 1 = средняя, 2 = правая (как в AppKit).
    // delta — для колёсика: положительное = увеличение.
    // --------------------------------------------------------------------------
    void onMouseDown(int button, float posX, float posY);
    void onMouseUp(int button, float posX, float posY);
    void onMouseMove(float posX, float posY);
    void onMouseScroll(float delta);

    // --------------------------------------------------------------------------
    // Обновить камеру (вызывается каждый кадр перед рендерингом).
    // --------------------------------------------------------------------------
    void update();

    // Настройки чувствительности
    void setRotationSpeed(float s) { m_rotationSpeed = s; }
    void setPanSpeed(float s) { m_panSpeed = s; }
    void setZoomSpeed(float s) { m_zoomSpeed = s; }

private:
    Camera* m_camera = nullptr;

    // Состояние кнопок
    bool m_leftButton  = false;
    bool m_rightButton = false;

    float m_lastMouseX = 0.0f;
    float m_lastMouseY = 0.0f;

    float m_rotationSpeed = 0.005f;
    float m_panSpeed      = 0.01f;
    float m_zoomSpeed     = 0.5f;

    // Вспомогательный метод для получения горизонтального и вертикального векторов камеры
    void getCameraVectors(Vector3& right, Vector3& up) const;
};

} // namespace MirEngine