// MirEngine/Scene/Camera.cpp
// =================================================================================
// Реализация камеры.
// =================================================================================

#include "Camera.h"
#include <algorithm>

namespace MirEngine {

// Локальные математические утилиты
static float dot(const Vector3& a, const Vector3& b) {
    return a.x*b.x + a.y*b.y + a.z*b.z;
}

static Vector3 cross(const Vector3& a, const Vector3& b) {
    return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x};
}

static Vector3 normalize(const Vector3& v) {
    float len = std::sqrt(dot(v, v));
    if (len > 1e-8f) return {v.x/len, v.y/len, v.z/len};
    return {0,0,0};
}

static Matrix4Raw identityMatrix() {
    return {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
}

// Умножение матриц 4x4 column-major
static Matrix4Raw multiply(const Matrix4Raw& a, const Matrix4Raw& b) {
    Matrix4Raw r;
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 4; ++row) {
            float s = 0.0f;
            for (int k = 0; k < 4; ++k) {
                s += a[row + k*4] * b[k + col*4];
            }
            r[row + col*4] = s;
        }
    }
    return r;
}

// Матрица lookAt (right-handed, как в OpenGL)
static Matrix4Raw lookAt(const Vector3& eye, const Vector3& center, const Vector3& up) {
    Vector3 f = normalize(center - eye);
    Vector3 s = normalize(cross(f, up));
    Vector3 u = cross(s, f);

    Matrix4Raw mat = identityMatrix();
    mat[0] = s.x;  mat[4] = s.y;  mat[8]  = s.z;  mat[12] = -dot(s, eye);
    mat[1] = u.x;  mat[5] = u.y;  mat[9]  = u.z;  mat[13] = -dot(u, eye);
    mat[2] = -f.x; mat[6] = -f.y; mat[10] = -f.z; mat[14] = dot(f, eye);
    // mat[3]=0, mat[7]=0, mat[11]=0, mat[15]=1
    return mat;
}

// Матрица перспективы (right-handed, clip space: -1..1 для OpenGL)
static Matrix4Raw perspective(float fovY, float aspect, float near, float far) {
    float f = 1.0f / std::tan(fovY * 0.5f);
    Matrix4Raw m = {};
    m[0] = f / aspect;
    m[5] = f;
    m[10] = (far + near) / (near - far);
    m[11] = -1.0f;
    m[14] = (2.0f * far * near) / (near - far);
    return m;
}

// Матрица ортогональной проекции (right-handed)
static Matrix4Raw ortho(float left, float right, float bottom, float top, float near, float far) {
    Matrix4Raw m = identityMatrix();
    m[0] = 2.0f / (right - left);
    m[5] = 2.0f / (top - bottom);
    m[10] = -2.0f / (far - near);
    m[12] = -(right + left) / (right - left);
    m[13] = -(top + bottom) / (top - bottom);
    m[14] = -(far + near) / (far - near);
    return m;
}

Camera::Camera() {
    // Инициализация базовой орбиты (камера смотрит на начало координат)
}

void Camera::setProjectionType(ProjectionType type) {
    if (m_projectionType != type) {
        m_projectionType = type;
        m_projDirty = true;
    }
}

void Camera::setPerspective(float fovYRadians, float aspect, float nearPlane, float farPlane) {
    m_projectionType = ProjectionType::Perspective;
    m_fovY = fovYRadians;
    m_aspect = aspect;
    m_near = nearPlane;
    m_far = farPlane;
    m_projDirty = true;
}

void Camera::setOrthographic(float left, float right, float bottom, float top, float nearPlane, float farPlane) {
    m_projectionType = ProjectionType::Orthographic;
    m_left = left; m_right = right;
    m_bottom = bottom; m_top = top;
    m_near = nearPlane; m_far = farPlane;
    m_projDirty = true;
}

void Camera::setTarget(const Vector3& target) {
    m_target = target;
    m_viewDirty = true;
}

void Camera::setOrbit(float theta, float phi, float distance) {
    m_theta = theta;
    m_phi = phi;
    m_distance = distance;
    m_viewDirty = true;
}

Vector3 Camera::getPosition() const {
    return computePosition();
}

Matrix4Raw Camera::getViewMatrix() const {
    if (m_viewDirty) {
        updateViewMatrix();
        m_viewDirty = false;
    }
    return m_viewMatrix;
}

Matrix4Raw Camera::getProjectionMatrix() const {
    if (m_projDirty) {
        updateProjectionMatrix();
        m_projDirty = false;
    }
    return m_projMatrix;
}

Vector3 Camera::computePosition() const {
    // Сферические координаты относительно target
    float x = m_target.x + m_distance * std::sin(m_phi) * std::cos(m_theta);
    float y = m_target.y + m_distance * std::cos(m_phi);
    float z = m_target.z + m_distance * std::sin(m_phi) * std::sin(m_theta);
    return {x, y, z};
}

void Camera::updateViewMatrix() const {
    Vector3 eye = computePosition();
    Vector3 up = {0.0f, 1.0f, 0.0f};
    // Если phi близко к полюсу, меняем up вектор
    if (std::abs(m_phi) < 0.001f || std::abs(m_phi - 3.14159f) < 0.001f) {
        up = {0.0f, 0.0f, 1.0f};
    }
    m_viewMatrix = lookAt(eye, m_target, up);
}

void Camera::updateProjectionMatrix() const {
    if (m_projectionType == ProjectionType::Perspective) {
        m_projMatrix = perspective(m_fovY, m_aspect, m_near, m_far);
    } else {
        m_projMatrix = ortho(m_left, m_right, m_bottom, m_top, m_near, m_far);
    }
}

} // namespace MirEngine