// MirEngine/Scene/CameraController.cpp
#include "CameraController.h"
#include "Camera.h"

namespace MirEngine {

CameraController::CameraController(Camera* camera) : m_camera(camera) {}

void CameraController::onMouseDown(int button, float posX, float posY) {
    if (button == 0) m_leftButton = true;
    if (button == 2) m_rightButton = true;
    m_lastMouseX = posX;
    m_lastMouseY = posY;
}

void CameraController::onMouseUp(int button, float /*posX*/, float /*posY*/) {
    if (button == 0) m_leftButton = false;
    if (button == 2) m_rightButton = false;
}

void CameraController::onMouseMove(float posX, float posY) {
    if (!m_camera) return;

    float dx = posX - m_lastMouseX;
    float dy = posY - m_lastMouseY;
    m_lastMouseX = posX;
    m_lastMouseY = posY;

    if (m_leftButton) {
        // Вращение
        float theta = m_camera->getTheta() - dx * m_rotationSpeed;
        float phi   = m_camera->getPhi()   + dy * m_rotationSpeed;
        // Ограничиваем phi, чтобы не перевернуться
        const float eps = 0.01f;
        const float pi = 3.14159265f;
        phi = std::clamp(phi, eps, pi - eps);
        m_camera->setOrbit(theta, phi, m_camera->getDistance());
    }

    if (m_rightButton) {
        // Панорамирование: сдвигаем target в плоскости камеры
        Vector3 right, up;
        getCameraVectors(right, up);
        Vector3 target = m_camera->getTarget();
        target = {target.x - right.x * dx * m_panSpeed + up.x * dy * m_panSpeed,
                  target.y - right.y * dx * m_panSpeed + up.y * dy * m_panSpeed,
                  target.z - right.z * dx * m_panSpeed + up.z * dy * m_panSpeed};
        m_camera->setTarget(target);
    }
}

void CameraController::onMouseScroll(float delta) {
    if (!m_camera) return;
    float dist = m_camera->getDistance() - delta * m_zoomSpeed;
    if (dist < 0.1f) dist = 0.1f;
    m_camera->setDistance(dist);
}

void CameraController::update() {
    // Пока не требуется, но может обновлять инерцию.
}

void CameraController::getCameraVectors(Vector3& right, Vector3& up) const {
    // Получаем направление взгляда
    Vector3 target = m_camera->getTarget();
    Vector3 pos = m_camera->getPosition();
    Vector3 dir = {target.x - pos.x, target.y - pos.y, target.z - pos.z};
    float len = std::sqrt(dir.x*dir.x + dir.y*dir.y + dir.z*dir.z);
    if (len > 0.001f) {
        dir.x /= len; dir.y /= len; dir.z /= len;
    }
    // Up вектор (мировой Y)
    Vector3 worldUp = {0, 1, 0};
    // Right = dir x worldUp
    right = {dir.y*worldUp.z - dir.z*worldUp.y,
             dir.z*worldUp.x - dir.x*worldUp.z,
             dir.x*worldUp.y - dir.y*worldUp.x};
    // Up = right x dir
    up = {right.y*dir.z - right.z*dir.y,
          right.z*dir.x - right.x*dir.z,
          right.x*dir.y - right.y*dir.x};
}

} // namespace MirEngine