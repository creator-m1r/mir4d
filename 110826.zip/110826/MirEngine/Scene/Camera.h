// MirEngine/Scene/Camera.h
// =================================================================================
// Камера сцены.
//
// Определяет точку обзора и параметры проекции. Генерирует view и projection
// матрицы, используемые RenderContext. Поддерживает перспективную и ортогональную
// проекции, а также орбитальное вращение вокруг целевой точки (target).
//
// Архитектура:
//   - Не зависит от рендеринг-бэкенда, только математика (Vector3, Matrix4).
//   - Используется Viewport для обновления RenderContext перед кадром.
//   - Может управляться контроллером камеры (будущий CameraController).
//
// Типы проекций:
//   - Perspective: классическая перспектива (fov, aspect, near/far).
//   - Orthographic: ортогональная (left, right, bottom, top, near/far) —
//     будет полезна для 2D-чертежей и некоторых CAD-режимов.
//
// Орбита:
//   - Позиция камеры вычисляется сферически относительно target.
//   - Углы theta (азимут), phi (зенит) и радиус distance определяют позицию.
//   - Направление взгляда всегда на target.
// =================================================================================

#pragma once

#include <array>
#include <cmath>
#include <cstdint>

namespace MirEngine {

// Временные математические типы (будут заменены на Core/Math)
struct Vector3 {
    float x = 0.0f, y = 0.0f, z = 0.0f;
    Vector3() = default;
    Vector3(float x, float y, float z) : x(x), y(y), z(z) {}
    Vector3 operator+(const Vector3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vector3 operator-(const Vector3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vector3 operator*(float s) const { return {x*s, y*s, z*s}; }
};

struct Vector4 {
    float x = 0.0f, y = 0.0f, z = 0.0f, w = 0.0f;
    Vector4() = default;
    Vector4(float x, float y, float z, float w) : x(x), y(y), z(z), w(w) {}
};

using Matrix4Raw = std::array<float, 16>; // column-major

// Вспомогательные функции для работы с матрицами (реализация в Camera.cpp)
Matrix4Raw inverseMatrix(const Matrix4Raw& m);
Vector4    multiplyMatrixVec4(const Matrix4Raw& m, const Vector4& v);

enum class ProjectionType {
    Perspective,
    Orthographic
};

class Camera {
public:
    Camera();

    // --------------------------------------------------------------------------
    // Тип проекции
    // --------------------------------------------------------------------------
    void setProjectionType(ProjectionType type);
    ProjectionType getProjectionType() const { return m_projectionType; }

    // --------------------------------------------------------------------------
    // Параметры перспективной проекции
    // --------------------------------------------------------------------------
    void setPerspective(float fovYRadians, float aspect, float nearPlane, float farPlane);
    void setAspectRatio(float aspect) { m_aspect = aspect; m_projDirty = true; }

    // --------------------------------------------------------------------------
    // Параметры ортогональной проекции
    // --------------------------------------------------------------------------
    void setOrthographic(float left, float right, float bottom, float top, float nearPlane, float farPlane);

    // --------------------------------------------------------------------------
    // Орбита: целевая точка (target), углы и дистанция.
    // Углы: theta (вращение вокруг вертикальной оси Y) в радианах,
    //       phi (зенит, 0 — полюс, PI — снизу) в радианах.
    // При изменении пересчитывается позиция камеры автоматически.
    // --------------------------------------------------------------------------
    void setTarget(const Vector3& target);
    void setOrbit(float theta, float phi, float distance);
    void setDistance(float distance) { m_distance = distance; m_viewDirty = true; }
    void setTheta(float theta) { m_theta = theta; m_viewDirty = true; }
    void setPhi(float phi)   { m_phi   = phi;   m_viewDirty = true; }

    // --------------------------------------------------------------------------
    // Получение текущих матриц (пересчитываются лениво)
    // --------------------------------------------------------------------------
    Matrix4Raw getViewMatrix() const;
    Matrix4Raw getProjectionMatrix() const;

    // --------------------------------------------------------------------------
    // Позиция камеры в мировом пространстве
    // --------------------------------------------------------------------------
    Vector3 getPosition() const;

    // --------------------------------------------------------------------------
    // Параметры плоскостей отсечения
    // --------------------------------------------------------------------------
    float getNearPlane() const { return m_near; }
    float getFarPlane() const  { return m_far; }

    // --------------------------------------------------------------------------
    // Построение луча из экранных координат (для picking'а и взаимодействия)
    // screenX, screenY — координаты в пикселях окна (0,0 — левый верхний угол)
    // vpWidth, vpHeight — размеры вьюпорта в пикселях
    // outOrigin    — точка начала луча (позиция камеры)
    // outDirection — единичный вектор направления луча в мировом пространстве
    // --------------------------------------------------------------------------
    void getRayFromScreen(float screenX, float screenY,
                          uint32_t vpWidth, uint32_t vpHeight,
                          Vector3& outOrigin, Vector3& outDirection) const;

private:
    // Внутренние методы пересчёта матриц
    void updateViewMatrix() const;
    void updateProjectionMatrix() const;

    // Кэши матриц и флаги dirty
    mutable Matrix4Raw m_viewMatrix;
    mutable Matrix4Raw m_projMatrix;
    mutable bool m_viewDirty = true;
    mutable bool m_projDirty = true;

    // Параметры проекции
    ProjectionType m_projectionType = ProjectionType::Perspective;
    float m_fovY    = 45.0f * 3.14159f / 180.0f; // 45 градусов
    float m_aspect  = 1.0f;
    float m_near    = 0.1f;
    float m_far     = 1000.0f;

    // Параметры ортогональной проекции
    float m_left   = -1.0f;
    float m_right  =  1.0f;
    float m_bottom = -1.0f;
    float m_top    =  1.0f;

    // Параметры орбиты
    Vector3 m_target   = {0.0f, 0.0f, 0.0f};
    float   m_theta    = 0.0f;          // азимут
    float   m_phi      = 1.570796f;     // зенит (PI/2 — экватор)
    float   m_distance = 5.0f;

    // Вычисление позиции камеры
    Vector3 computePosition() const;
};

} // namespace MirEngine